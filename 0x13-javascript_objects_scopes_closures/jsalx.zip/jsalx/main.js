#!/usr/bin/node
exports.list = [1, 2, 3, 4, 5];
