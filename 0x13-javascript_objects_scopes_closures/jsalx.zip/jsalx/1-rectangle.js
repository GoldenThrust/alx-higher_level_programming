#!/usr/bin/node
class Rectangle {
    width;
    height;
    constructor(w, h) {
        this.width = w;
        this.height = h;
    }
}

module.exports = Rectangle
