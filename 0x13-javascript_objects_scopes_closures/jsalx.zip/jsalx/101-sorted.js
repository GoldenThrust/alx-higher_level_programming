#!/usr/bin/node

let dict = require('./101-data.js').dict;

let obj = {};

for (const val in dict) {
    const ocur = dict[val];
    
    if (obj[ocur]) {
        obj[ocur].push(val);
    } else {
        obj[ocur] = [val]; 
    }
}
console.log(obj);
