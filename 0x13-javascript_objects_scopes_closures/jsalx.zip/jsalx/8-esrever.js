#!/usr/bin/node
exports.esrever = function (list) {
    return list.reverse();
}
